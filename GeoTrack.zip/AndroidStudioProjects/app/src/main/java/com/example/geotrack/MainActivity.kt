package com.example.geotrack

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import java.text.DateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    private lateinit var latitude: TextView
    private lateinit var longitudine: TextView
    private lateinit var gpsStatus: TextView
    private lateinit var provider: TextView
    private lateinit var accuracy: TextView
    private lateinit var country: TextView
    private lateinit var locality: TextView
    private lateinit var address: TextView
    private lateinit var gpsStatusReceiver: BroadcastReceiver

    @SuppressLint("MissingPermission", "MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val exitButton = findViewById<Button>(R.id.exitbt)
        exitButton.setOnClickListener {
            finishAffinity()
        }

        val aboutButton = findViewById<Button>(R.id.Despre)
        aboutButton.setOnClickListener {
            val intent = Intent(this, aboutActivity::class.java)
            startActivity(intent)
        }

        val mapButton = findViewById<Button>(R.id.Mapa)
        mapButton.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        longitudine = findViewById(R.id.Lng)
        latitude = findViewById(R.id.Lta)
        gpsStatus = findViewById(R.id.gps_status)
        provider = findViewById(R.id.Provider)
        accuracy = findViewById(R.id.acuratete)
        country = findViewById(R.id.Contry)
        locality = findViewById(R.id.Localitate)
        address = findViewById(R.id.Adresa)
        val button = findViewById<Button>(R.id.Locare)

        // Initializează receptorul pentru statusul GPS
        initGpsStatusReceiver()

        // Updatează textul pentru statusul GPS și providerul de localizare
        checkGpsStatus()
        getProvider()

        //########################################################

        val calendar = Calendar.getInstance().time
        val dateFormat = DateFormat.getDateInstance(DateFormat.DEFAULT).format(calendar)
        val dateTextView = findViewById<TextView>(R.id.Data)
        dateTextView.text = dateFormat
        val timeFormat = DateFormat.getTimeInstance(DateFormat.SHORT).format(calendar)
        val timeTextView = findViewById<TextView>(R.id.Ora)
        timeTextView.text = "Ora: $timeFormat"

        //########################################################

        button.setOnClickListener {
            getLocation()
        }
    }

    private fun initGpsStatusReceiver() {
        gpsStatusReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                if (intent?.action == LocationManager.PROVIDERS_CHANGED_ACTION) {
                    checkGpsStatus()
                }
            }
        }
        val filter = IntentFilter(LocationManager.PROVIDERS_CHANGED_ACTION)
        registerReceiver(gpsStatusReceiver, filter)
    }

    private fun checkGpsStatus() {
        val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        val isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val gpsStatusText = if (isGpsEnabled) "GPS Status: Enabled" else "GPS Status: Disabled"
        gpsStatus.text = gpsStatusText
    }

    private fun getProvider() {
        val locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = locationManager.getProviders(true)
        val gpsProvider = providers.find { it == LocationManager.GPS_PROVIDER }
        val providerText = "Furnizor: ${gpsProvider?.toUpperCase() ?: "Furnizorul GPS nu este disponibil"}"
        provider.text = providerText
    }

    @SuppressLint("MissingPermission")
    private fun getLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED &&
            ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                100
            )
            return
        }

        fusedLocationProviderClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val textLatitude = "Latitudine: " + location.latitude.toString()
                val textLongitude = "Longitudine: " + location.longitude.toString()
                val textAccuracy = "Acuratețe: " + location.accuracy.toString() + " metri"
                latitude.text = textLatitude
                longitudine.text = textLongitude
                accuracy.text = textAccuracy

                // Use Geocoder to get the address details
                val geocoder = Geocoder(this, Locale.getDefault())
                try {
                    val addresses = geocoder.getFromLocation(location.latitude, location.longitude, 1)
                    if (addresses != null && addresses.isNotEmpty()) {
                        val addressObj = addresses[0]
                        val countryName = "Country: " + (addressObj.countryName ?: "N/A")
                        val localityName = "Locality: " + (addressObj.locality ?: "N/A")
                        val addressLine = "Address: " + (addressObj.getAddressLine(0) ?: "N/A")
                        country.text = countryName
                        locality.text = localityName
                        address.text = addressLine
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            } else {
                latitude.text = "Unable to find location"
                longitudine.text = ""
                accuracy.text = ""
                country.text = ""
                locality.text = ""
                address.text = ""
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        unregisterReceiver(gpsStatusReceiver)
    }
}
